document.addEventListener('DOMContentLoaded', () => {
    const overlay = document.getElementById('overlay');
    let powerButtonPressCount = 0;
    let touchDisabled = true;

    // Disable touch interactions
    document.body.addEventListener('touchstart', (event) => {
        if (touchDisabled) {
            event.preventDefault();
        }
    }, { passive: false });

    // Function to simulate pressing the power button twice
    document.body.addEventListener('keydown', (event) => {
        if (event.key.toLowerCase() === 'on') {
            powerButtonPressCount++;
            if (powerButtonPressCount === 2) {
                toggleTouchInteraction();
                powerButtonPressCount = 0;
            }
            setTimeout(() => {
                powerButtonPressCount = 0;
            }, 1000); // Reset counter after 1 second
        }
    });

    function toggleTouchInteraction() {
        touchDisabled = !touchDisabled;
        overlay.style.display = touchDisabled ? 'flex' : 'none';
    }

    // Initial state: touch interactions are disabled
    toggleTouchInteraction();
});
